# ASIX1_M4_UF1_A2_EvaluacionInicial
Primer ejercicio de preguntas


1. ¿Qué es una página web?


Respuesta.


2. ¿Qué es un sitio web?


Respuesta.


3. ¿Qué es una aplicación web?


Respuesta.


4. ¿Qué es una herramienta ofimática?


Respuesta.


5. [Herramientas de Google:](https://about.google/products/ "enlace a las herramientas de google")

|Aplicaciones|Visto|
|-----------|----|
|Google Docs|✔️|
|Google Slides|✔️|
|Google Sheets|✔️|
|Google Calendar|📅|
|Google Meet|💻|
|...|...|


6. ¿Qué es HTML ?


Respuesta.

![Imagen1](https://github.com/Marioto33/ASIX1_M4_UF1_A2_EvaluacionInicial/blob/main/imagen%201.png)


7. ¿Qué es CSS?


Respuesta.


Flujo de trabajo (navegador, petición, servidor y respuesta):
![Imagen2](https://github.com/Marioto33/ASIX1_M4_UF1_A2_EvaluacionInicial/blob/main/imagen%202.png)